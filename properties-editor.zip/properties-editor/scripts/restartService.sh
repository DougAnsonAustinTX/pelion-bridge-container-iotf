#!/bin/sh

restart_service() 
{
    cd ${HOME}
    rm -f restart.log > /dev/null 2>&1
    ${HOME}/restart.sh > ${HOME}/restart.log 2>&1 &
}

main()
{
    restart_service $*
}

main $*
